#include <webots/robot.h>
#include <webots/motor.h>

#define TIME_STEP 32

int main() {
  wb_robot_init();

  WbDeviceTag motor = wb_robot_get_device("motor");
  wb_motor_set_position(motor, 38 * 3.14159 / 180.0); // 轉到 38 度

  while (wb_robot_step(TIME_STEP) != -1) {
    // 模擬持續運行
  }

  wb_robot_cleanup();
  return 0;
}
