在這次的專案中，我們使用了兩個 Webots 模擬環境檔案：

youbot_cart_w14_w_plate.wbt：該環境中放置了一個尺寸為長50公分、寬30公分、高2公分的平台，搭載在Youbot推車上，提供穩定的工作平台。

youbot_cart_w14_w_plate_small_shooter_feed_ball.wbt：此環境加入了發球機構，並設計了多種操作方式。按鍵 “a” 可使用 Supervisor 對 Youbot 相對位置產生靜態球（預設位置為(-0.35, 0.0, 0.9)），按鍵 “m” 可將靜態球替換為動態球並旋轉壓板40度完成射球動作，按鍵 “k” 則將壓板旋回初始位置，另外用方向鍵可控制 Youbot 推車的移動。