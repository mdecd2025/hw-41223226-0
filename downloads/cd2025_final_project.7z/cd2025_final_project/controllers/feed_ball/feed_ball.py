from controller import Supervisor, Keyboard
import time
import random
import numpy as np
import re

class BallManager:
    # 球體半徑
    SPHERE_RADIUS = 0.1
    # 軌跡點半徑
    TRAJECTORY_POINT_RADIUS = 0.03
    # 軌跡點距離間隔
    TRAJECTORY_POINT_STEP = 0.12
    # 軌跡點最大數量
    TRAJECTORY_MAX_POINTS = 5
    # 按鍵去彈跳時間(秒)
    DEBOUNCE_TIME = 0.5
    # 印出位置資訊間隔(秒)
    PRINT_INTERVAL = 0.2
    # 球落地判斷閾值(z軸高度)
    LANDING_THRESHOLD_Z = 0.13

    def __init__(self, supervisor: Supervisor):
        self.supervisor = supervisor
        self.timestep = int(supervisor.getBasicTimeStep())
        self.keyboard = Keyboard()
        self.keyboard.enable(self.timestep)  # 啟用鍵盤偵測

        # 等待擊出的靜止球的 DEF 名稱和資訊
        self.waiting_ball_def = None
        self.waiting_ball_info = None

        self.last_key_time = 0  # 上次按鍵時間(用於去彈跳)
        self.last_print_time = 0  # 上次印出位置時間

        self.trajectory_points = []  # 軌跡點列表，存 (位置, DEF 名稱)
        self.current_tracked_def = None  # 目前追蹤的球 DEF 名稱

        # 取得 youbot 節點，用來做座標轉換
        self.youbot_node = supervisor.getFromDef('youbot')
        if self.youbot_node is None:
            raise RuntimeError("找不到 DEF 為 youbot 的 Robot 物件")

        # 球產生的本地位置 (相對 youbot)
        self.default_feed_pos = (-0.35, 0.0, 0.9)

        # 用來匹配球 DEF 名稱的正則表達式（目前未用，但可擴充）
        self.ball_def_pattern = re.compile(r"Sphere_\d+")

    def axis_angle_to_rotation_matrix(self, axis, angle):
        # 將軸角旋轉轉成 3x3 旋轉矩陣 (numpy陣列)
        x, y, z = axis
        c = np.cos(angle)
        s = np.sin(angle)
        C = 1 - c
        return np.array([
            [x*x*C + c,   x*y*C - z*s, x*z*C + y*s],
            [y*x*C + z*s, y*y*C + c,   y*z*C - x*s],
            [z*x*C - y*s, z*y*C + x*s, z*z*C + c]
        ])

    def generate_valid_def_name(self, base_name="Sphere"):
        # 產生唯一的 DEF 名稱，防止重複衝突
        timestamp = int(self.supervisor.getTime() * 1000)
        return f"{base_name}_{timestamp}_{random.randint(0, 10000)}"

    def generate_random_color(self):
        # 隨機產生 RGB 三色(0~1之間浮點數)
        return random.random(), random.random(), random.random()

    def youbot_local_to_world(self, local_pos):
        # 將 youbot 本地座標轉換成世界座標
        youbot_translation = np.array(self.youbot_node.getField('translation').getSFVec3f())
        youbot_rotation = self.youbot_node.getField('rotation').getSFRotation()
        axis = youbot_rotation[:3]
        angle = youbot_rotation[3]
        rot_mat = self.axis_angle_to_rotation_matrix(axis, angle)
        rotated = rot_mat @ np.array(local_pos)
        world_pos = youbot_translation + rotated
        return tuple(world_pos)

    def create_static_ball(self, def_name, world_pos, r, g, b):
        # 在世界中產生靜止的球
        sphere_str = f"""
        DEF {def_name} Solid {{
          translation {world_pos[0]} {world_pos[1]} {world_pos[2]}
          contactMaterial "ball"
          children [
            Shape {{
              geometry Sphere {{
                radius {self.SPHERE_RADIUS}
              }}
              appearance Appearance {{
                material Material {{
                  diffuseColor {r} {g} {b}
                }}
              }}
            }}
          ]
          boundingObject Sphere {{
            radius {self.SPHERE_RADIUS}
          }}
        }}
        """
        self.supervisor.getRoot().getField("children").importMFNodeFromString(-1, sphere_str)

    def create_dynamic_ball(self, def_name, world_pos, r, g, b):
        # 在世界中產生可動態物理的球（可被擊出）
        sphere_str = f"""
        DEF {def_name} Solid {{
          translation {world_pos[0]} {world_pos[1]} {world_pos[2]}
          contactMaterial "ball"
          children [
            Shape {{
              geometry Sphere {{
                radius {self.SPHERE_RADIUS}
              }}
              appearance Appearance {{
                material Material {{
                  diffuseColor {r} {g} {b}
                }}
              }}
            }}
          ]
          boundingObject Sphere {{
            radius {self.SPHERE_RADIUS}
          }}
          physics Physics {{
            mass 0.01
            density -1
          }}
        }}
        """
        self.supervisor.getRoot().getField("children").importMFNodeFromString(-1, sphere_str)

    def create_trajectory_point(self, pos):
        # 建立一個透明橘色小球作為軌跡點
        def_name = self.generate_valid_def_name("TrajectoryPt")
        sphere_str = f"""
        DEF {def_name} Transform {{
          translation {pos[0]} {pos[1]} {pos[2]}
          children [
            Shape {{
              geometry Sphere {{
                radius {self.TRAJECTORY_POINT_RADIUS}
              }}
              appearance Appearance {{
                material Material {{
                  diffuseColor 1 0.7 0
                  transparency 0.3
                }}
              }}
            }}
          ]
        }}
        """
        self.supervisor.getRoot().getField("children").importMFNodeFromString(-1, sphere_str)
        return def_name

    def delete_trajectory_points(self):
        # 刪除所有軌跡點物件
        for _, def_name in self.trajectory_points:
            node = self.supervisor.getFromDef(def_name)
            if node:
                node.remove()
        self.trajectory_points.clear()

    def create_static_sphere(self, x, y, z):
        # 嘗試產生一顆靜止球
        if self.waiting_ball_def is not None:
            print("還有一顆球等待擊出，請先擊出再產生新球。")
            return False
        def_name = self.generate_valid_def_name()
        world_pos = self.youbot_local_to_world((x, y, z))
        r, g, b = self.generate_random_color()
        self.waiting_ball_def = def_name
        self.waiting_ball_info = (world_pos, r, g, b)
        self.create_static_ball(def_name, world_pos, r, g, b)
        self.current_tracked_def = def_name
        self.delete_trajectory_points()  # 新球產生，清除舊軌跡點
        print(f"已產生靜止球 {def_name} 於 {world_pos}")
        return True

    def activate_dynamic_ball(self):
        # 將等待的靜止球刪除並重新產生為動態球（可被擊出）
        if self.waiting_ball_def is None or self.waiting_ball_info is None:
            print("沒有等待擊出的球。")
            return False
        ball_node = self.supervisor.getFromDef(self.waiting_ball_def)
        if ball_node:
            ball_node.remove()
            self.supervisor.step(self.timestep)  # 等待場景更新
        world_pos, r, g, b = self.waiting_ball_info
        self.create_dynamic_ball(self.waiting_ball_def, world_pos, r, g, b)
        print(f"球 {self.waiting_ball_def} 變成動態球")
        self.waiting_ball_def = None
        self.waiting_ball_info = None
        return True

    def is_ball_landed(self, pos):
        # 判斷球是否已落地(根據 z 軸高度)
        return pos[2] < self.LANDING_THRESHOLD_Z

    def run(self):
        # 主程式迴圈，處理按鍵與軌跡追蹤
        print("按 A 產生一顆靜止球，按 M 讓球變 dynamic 可擊出")
        while self.supervisor.step(self.timestep) != -1:
            key = self.keyboard.getKey()
            current_time = time.time()

            # 按鍵去彈跳判斷
            if key != -1 and (current_time - self.last_key_time < self.DEBOUNCE_TIME):
                key = -1

            if key == ord('A'):
                # 按 A 產生靜止球
                if self.create_static_sphere(*self.default_feed_pos):
                    self.last_key_time = current_time

            elif key == ord('M'):
                # 按 M 使球成為動態球
                if self.activate_dynamic_ball():
                    self.last_key_time = current_time

            # 軌跡點追蹤
            if self.current_tracked_def:
                ball_node = self.supervisor.getFromDef(self.current_tracked_def)
                if ball_node:
                    pos = ball_node.getPosition()
                    # 定時印出位置資訊
                    if current_time - self.last_print_time >= self.PRINT_INTERVAL:
                        print(f"球 {self.current_tracked_def} 位置: [{pos[0]:.4f}, {pos[1]:.4f}, {pos[2]:.4f}]")
                        self.last_print_time = current_time

                    # 如果球移動超過軌跡間距，新增軌跡點
                    if (not self.trajectory_points) or np.linalg.norm(np.array(pos) - np.array(self.trajectory_points[-1][0])) > self.TRAJECTORY_POINT_STEP:
                        def_name = self.create_trajectory_point(pos)
                        self.trajectory_points.append((pos, def_name))
                        # 軌跡點數量超過限制，刪除最舊的
                        if len(self.trajectory_points) > self.TRAJECTORY_MAX_POINTS:
                            _, old_def = self.trajectory_points.pop(0)
                            old_node = self.supervisor.getFromDef(old_def)
                            if old_node:
                                old_node.remove()

                    # 球落地，清除軌跡點
                    if self.is_ball_landed(pos):
                        self.delete_trajectory_points()
                else:
                    # 找不到球，清除軌跡並停止追蹤
                    self.delete_trajectory_points()
                    self.current_tracked_def = None

if __name__ == "__main__":
    supervisor = Supervisor()
    ball_manager = BallManager(supervisor)
    ball_manager.run()