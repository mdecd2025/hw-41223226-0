from controller import Robot, Keyboard

# 常數設定
TIME_STEP = 32  # 模擬步長 (ms)
MAX_VELOCITY = 10.0  # 馬達最大速度
ANGLE_STEP = 40 * 3.14159 / 180  # 40度轉弧度
POSITION_M = ANGLE_STEP  # 馬達目標位置 +40度
POSITION_K = 0.0         # 馬達目標位置 0度

# 初始化機器人、鍵盤
robot = Robot()
timestep = int(robot.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)

# 嘗試初始化馬達與感測器
mechanism_enabled = False
motor = None
sensor = None
try:
    motor = robot.getDevice('motor1')
    sensor = robot.getDevice('motor1_sensor')
    sensor.enable(timestep)
    mechanism_enabled = True
except Exception as e:
    print(f"機構控制裝置初始化失敗: {e}")

# 嘗試初始化輪子馬達
platform_enabled = False
wheels = []
try:
    wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
    for wheel in wheels:
        wheel.setPosition(float('inf'))  # 無限位置啟動速度控制
        wheel.setVelocity(0)
    platform_enabled = True
except Exception as e:
    print(f"平台控制裝置初始化失敗: {e}")

# 狀態機，用來控制 M / K 的切換（避免重複觸發）
current_state = "allow_m"

# 防止長按重複觸發的旗標
key_pressed = {'m': False, 'k': False}

def stop_wheels():
    for w in wheels:
        w.setVelocity(0)

print("控制開始，使用方向鍵移動，M/K控制機構，Q退出")

while robot.step(timestep) != -1:
    key = keyboard.getKey()

    # 平台控制
    if platform_enabled:
        if key == Keyboard.UP:
            for w in wheels:
                w.setVelocity(MAX_VELOCITY)
        elif key == Keyboard.DOWN:
            for w in wheels:
                w.setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.LEFT:
            # 左輪後退，右輪前進
            wheels[0].setVelocity(-MAX_VELOCITY)
            wheels[1].setVelocity(MAX_VELOCITY)
            wheels[2].setVelocity(-MAX_VELOCITY)
            wheels[3].setVelocity(MAX_VELOCITY)
        elif key == Keyboard.RIGHT:
            # 左輪前進，右輪後退
            wheels[0].setVelocity(MAX_VELOCITY)
            wheels[1].setVelocity(-MAX_VELOCITY)
            wheels[2].setVelocity(MAX_VELOCITY)
            wheels[3].setVelocity(-MAX_VELOCITY)
        elif key in (ord('Q'), ord('q')):
            print("Exiting...")
            break
        else:
            stop_wheels()

    # 機構控制
    if mechanism_enabled:
        motor_pos = sensor.getValue()
        # print(f"Motor pos: {motor_pos:.3f}")  # 除錯用
        
        # 按下 M，移動到 +40 度，且只有當狀態允許時觸發
        if key in (ord('M'), ord('m')):
            if not key_pressed['m'] and current_state == "allow_m":
                motor.setPosition(POSITION_M)
                current_state = "allow_k"
            key_pressed['m'] = True
        else:
            key_pressed['m'] = False

        # 按下 K，回到 0 度，且只有當狀態允許時觸發
        if key in (ord('K'), ord('k')):
            if not key_pressed['k'] and current_state == "allow_k":
                motor.setPosition(POSITION_K)
                current_state = "allow_m"
            key_pressed['k'] = True
        else:
            key_pressed['k'] = False