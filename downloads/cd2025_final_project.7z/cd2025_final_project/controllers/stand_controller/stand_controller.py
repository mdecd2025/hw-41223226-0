from controller import Robot, Keyboard

# 常數設定
WHEEL_RADIUS = 0.1  # 輪子半徑(公尺)
ROBOT_LENGTH_HALF = 0.471  # 機器人長度一半(公尺)
ROBOT_WIDTH_HALF = 0.376  # 機器人寬度一半(公尺)
MAX_VELOCITY = 10.0  # 馬達最大速度

# 初始化機器人與時間步長
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# 初始化距離感測器並啟用
distance_sensor = robot.getDevice('sensor')
distance_sensor.enable(timestep)

# 初始化鍵盤並啟用
keyboard = Keyboard()
keyboard.enable(timestep)

# 初始化輪子馬達並設為速度控制模式
wheels = {
    'front_right': robot.getDevice("wheel5"),
    'front_left': robot.getDevice("wheel6"),
    'rear_right': robot.getDevice("wheel7"),
    'rear_left': robot.getDevice("wheel8")
}
for wheel in wheels.values():
    wheel.setPosition(float('inf'))  # 無限位置控制速度模式
    wheel.setVelocity(0)  # 初始速度0

# AD值對應距離的查表(線性插值用)
lookup_table = [
    (1000, 0.00),
    (620, 0.12),
    (372, 0.13),
    (248, 0.14),
    (186, 0.15),
    (0, 0.18)
]

def ad_to_distance(ad_value):
    """用線性插值將感測器AD值轉換成距離(公尺)"""
    for i in range(len(lookup_table)-1):
        a0, d0 = lookup_table[i]
        a1, d1 = lookup_table[i+1]
        if a0 >= ad_value >= a1:
            return d0 + (d1 - d0) * (ad_value - a0) / (a1 - a0)
    if ad_value > lookup_table[0][0]:
        return lookup_table[0][1]
    return lookup_table[-1][1]

def set_all_wheel_velocity(v):
    """設定所有輪子相同速度"""
    for wheel in wheels.values():
        wheel.setVelocity(v)

def set_wheel_velocities(v_front_right, v_front_left, v_rear_right, v_rear_left):
    """設定四個輪子的速度"""
    wheels['front_right'].setVelocity(v_front_right)
    wheels['front_left'].setVelocity(v_front_left)
    wheels['rear_right'].setVelocity(v_rear_right)
    wheels['rear_left'].setVelocity(v_rear_left)

# 按鍵與對應的動作(函式)對應表
def move_forward():
    set_all_wheel_velocity(MAX_VELOCITY)

def move_backward():
    set_all_wheel_velocity(-MAX_VELOCITY)

def turn_right():
    set_wheel_velocities(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)

def turn_left():
    set_wheel_velocities(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)

def stop():
    set_all_wheel_velocity(0)

key_action_map = {
    ord('E'): move_forward,
    ord('e'): move_forward,
    ord('X'): move_backward,
    ord('x'): move_backward,
    ord('D'): turn_right,
    ord('d'): turn_right,
    ord('S'): turn_left,
    ord('s'): turn_left
}

# 計分相關變數
score = 0
last_score_time = 0
score_cooldown = 1.0  # 冷卻時間(秒)

print("控制說明：")
print("E: 前進, X: 後退, S: 左轉, D: 右轉, Q: 退出")
print("M或K鍵可查看目前距離感測器數值")

while robot.step(timestep) != -1:
    key = keyboard.getKey()
    sensor_value = distance_sensor.getValue()
    distance = ad_to_distance(sensor_value)
    current_time = robot.getTime()

    # 調試用：印出距離值
    if key in [ord('M'), ord('m'), ord('K'), ord('k')]:
        print(f"距離感測器讀值: {distance:.3f} 公尺")

    # 判斷是否得分(距離小於門檻且冷卻時間已過)
    if distance < 0.11 and (current_time - last_score_time) > score_cooldown:
        score += 2
        last_score_time = current_time
        print(f"得分! 總分: {score}, 距離: {distance:.3f}")

    # 按鍵操作
    if key in key_action_map:
        key_action_map[key]()
    elif key in [ord('Q'), ord('q')]:
        print("離開程式中...")
        break
    else:
        # 無按鍵，停止輪子
        stop()
